<?php

declare(strict_types=1);

namespace Carbon\Doctrine;

class CarbonType extends DateTimeType implements CarbonDoctrineType
{
}
